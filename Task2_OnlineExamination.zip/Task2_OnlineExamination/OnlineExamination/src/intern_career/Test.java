package intern_career;

import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.util.TimerTask;

/**
 * students can take a test after the test is been created
 *
 * @author (PHILEMON MOLEWA)
 */
public class Test extends javax.swing.JFrame
{

    int counter = 0;
    boolean isIt = false;

    /**
     * Creates new form Question
     */
    public Test()
    {
        initComponents();

        connect(); //call the connetion method
        loadQuestions(); // call the load method

    }

    ;

    // method to auto submit
    public void autoSubmit()
    {
        int time = Integer.parseInt(lblTime.getText());
        if (time == 0)
        {
            JOptionPane.showMessageDialog(this, "Your time is over!");
          
            AutoSubmit objAutoSubmit = new AutoSubmit();
            objAutoSubmit.setVisible(true);
            close(); // close the current form
        }

    }

    // creating a connection object
    Connection con;

    public void connect()
    {
        try
        {
            // register Mysql driver
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/onlineexam", "root", ""); // username and password of mysql

        }
        catch (ClassNotFoundException ex)
        {
            Logger.getLogger(User.class
                    .getName()).log(Level.SEVERE, null, ex);

        }
        catch (SQLException ex)
        {
            Logger.getLogger(User.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    //String correctAnswer;
    PreparedStatement pat;
    ResultSet rs;
    String cor = null;

    public void loadQuestions()
    {
        //answerCheck(); // temporary

        String query = "select * from tblquestion";
        Statement stat = null; // Stetement class
        try
        {
            stat = con.createStatement(); // object
            rs = stat.executeQuery(query);

            while (rs.next())
            {
                jLabel3.setText(rs.getString(1));
                jLabel2.setText(rs.getString(2));
                rdOne.setText(rs.getString(3));
                rdTwo.setText(rs.getString(4));
                rdThree.setText(rs.getString(5));
                rdFour.setText(rs.getString(6));

                cor = rs.getString(7);
                // for only one row

                /*
                if (!AlreadyAnswered())
                {
                    // clearall buttons when proceed to next question and it is not answered
                    buttonGroup1.clearSelection();
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "This is first record or user");
                }
                 
                 */
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    int answercheck = 0;
    int marks = 0;
    String answer = null;

    // check answer method
    public boolean answerCheck()
    {
        String answerAnswer = "";

        if (rdOne.isSelected())
        {
            answerAnswer = rdOne.getText();
        }
        else if (rdTwo.isSelected())
        {
            answerAnswer = rdTwo.getText();
        }
        else if (rdThree.isSelected())
        {
            answerAnswer = rdThree.getText();
        }
        else if (rdFour.isSelected())
        {
            answerAnswer = rdFour.getText();
        }
        if (answerAnswer.equals(cor) && (answer == null || !answer.equals(cor)))
        {
            marks += 1;

            lblMarks.setText(String.valueOf(marks));
        }

        /*
        else if (!answerAnswer.equals(cor) && answer != null)
        {
            // only deduct if marks greater than zero
            if (marks > 0) 
            {
                marks = marks;
            }
            
            lblMarks.setText(String.valueOf(marks));
        }
         */
        
        /*
        // use to store answers
        if (!answerAnswer.equals(""))
        {
            try
            {
                String query = "UPDATE tblquestion SET givenAnswer = ? WHERE tblquestion = ?";
                pat = con.prepareStatement(query);
                pat.setString(1, answerAnswer);
                pat.setString(2, jLabel2.getText());
                pat.execute();
            }
            catch (SQLException ex)
            {
                ex.printStackTrace();
            }

            return true;
        }
         */
        
        //  nullAllGivenAnswer();
        // when no button is selected
        return false;
    }

    // method if the answer is null
    public void nullAllGivenAnswer()
    {
        try
        {

            String query = "UPDATE tblquestion SET givenAnswer = ?";
            pat = con.prepareStatement(query);
            pat.setString(1, null);
            pat.execute();
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        }
    }

    // close previous window form
    public void close()
    {
        WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
    }

    ResultSet res;
    Statement stat;

    private boolean AlreadyAnswered()
    {
        String query = "SELECT givenAnswer FROM tblquestion WHERE tblquestion = '" + jLabel2.getText() + "'";
        try
        {
            stat = con.prepareStatement(query);
        }
        catch (SQLException ex)
        {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

        try
        {
            res = stat.executeQuery(query);
        }
        catch (SQLException ex)
        {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

        try
        {
            while (res.next())
            {

                try
                {
                    answer = res.getString("givenAnswer");
                }
                catch (SQLException ex)
                {
                    Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (answer == null)
                {
                    return false;
                }
                break;
            }

            if (rdOne.getText().equals(answer))
            {
                rdOne.setSelected(true);
            }

            else if (rdTwo.getText().equals(answer))
            {
                rdTwo.setSelected(true);
            }

            else if (rdThree.getText().equals(answer))
            {
                rdThree.setSelected(true);
            }

            else if (rdFour.getText().equals(answer))
            {
                rdFour.setSelected(true);
            }

        }
        catch (SQLException ex)
        {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false; // when no button is selected  
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        rdOne = new javax.swing.JRadioButton();
        rdTwo = new javax.swing.JRadioButton();
        rdThree = new javax.swing.JRadioButton();
        rdFour = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        btnNextQuestion = new javax.swing.JButton();
        lblMarks = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblTime = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnTakeTest = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Online Test");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Question");

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        buttonGroup1.add(rdOne);
        rdOne.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rdOne.setText("jRadioButton1");

        buttonGroup1.add(rdTwo);
        rdTwo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rdTwo.setText("jRadioButton2");

        buttonGroup1.add(rdThree);
        rdThree.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rdThree.setText("jRadioButton3");

        buttonGroup1.add(rdFour);
        rdFour.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rdFour.setText("jRadioButton4");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdOne)
                    .addComponent(rdTwo)
                    .addComponent(rdThree)
                    .addComponent(rdFour))
                .addContainerGap(173, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(rdOne)
                .addGap(27, 27, 27)
                .addComponent(rdTwo)
                .addGap(26, 26, 26)
                .addComponent(rdThree)
                .addGap(30, 30, 30)
                .addComponent(rdFour)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("No");

        btnNextQuestion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnNextQuestion.setText("Next");
        btnNextQuestion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnNextQuestion.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextQuestionActionPerformed(evt);
            }
        });

        lblMarks.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblMarks.setForeground(new java.awt.Color(0, 204, 51));
        lblMarks.setText("0");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("mark");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Time left:");

        lblTime.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblTime.setForeground(new java.awt.Color(255, 102, 102));
        lblTime.setText("10");

        jLabel6.setText("Read the question carefully and answer the following questions");

        jLabel7.setText("This test has a time limit of 10 seconds each question, failure to");

        jLabel8.setText("answer a question in time the test will AUTO SUBMIT. ");

        jLabel9.setText("Wishing you best of luck!");

        btnTakeTest.setBackground(new java.awt.Color(0, 204, 204));
        btnTakeTest.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnTakeTest.setText("Take Test");
        btnTakeTest.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTakeTest.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnTakeTestActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Question");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTime)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(jLabel10)
                        .addGap(27, 27, 27))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)))
                .addComponent(jLabel3)
                .addGap(37, 37, 37))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(btnTakeTest, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(79, 79, 79)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addContainerGap(118, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnNextQuestion, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMarks, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(349, 349, 349))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTime)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel9)
                        .addGap(28, 28, 28)
                        .addComponent(btnTakeTest, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNextQuestion)
                    .addComponent(lblMarks))
                .addContainerGap(124, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNextQuestionActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextQuestionActionPerformed
    {//GEN-HEADEREND:event_btnNextQuestionActionPerformed

        answerCheck();
        loadQuestions();

        /*
        close();
        Test objTest = new Test();
        objTest.setVisible(true);
         */
 /*
       
        
        // set timer for the test
        java.util.Timer timer = new java.util.Timer();
        counter = 10;
        TimerTask task = new TimerTask()
        {
            public void run()
            {

                lblTime.setText(Integer.toString(counter));
                counter--;
                if (counter == -1)
                {
                    timer.cancel();

                }
                else
                {
                    if (isIt)
                    {
                        timer.cancel();
                        isIt = false;
                    }
                }
                autoSubmit(); // call the autoSubmit method
               // close();
            }
        ;
        };
         
       timer.scheduleAtFixedRate(task, 1000, 1000);
         */

    }//GEN-LAST:event_btnNextQuestionActionPerformed


    private void btnTakeTestActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnTakeTestActionPerformed
    {//GEN-HEADEREND:event_btnTakeTestActionPerformed
        // TODO add your handling code here:

        // set timer for the test
        java.util.Timer timer = new java.util.Timer();
        counter = 10;
        TimerTask task = new TimerTask()
        {
            public void run()
            {

                lblTime.setText(Integer.toString(counter));
                counter--;
                if (counter == -1)
                {
                    timer.cancel();

                }
                else
                {
                    if (isIt)
                    {
                        timer.cancel();
                        isIt = false;
                    }
                }
                autoSubmit(); // call the autoSubmit method
            }
        ;
        };
        timer.scheduleAtFixedRate(task, 1000, 1000);
    }//GEN-LAST:event_btnTakeTestActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Test.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Test.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Test.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Test.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Test().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNextQuestion;
    private javax.swing.JButton btnTakeTest;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblMarks;
    private javax.swing.JLabel lblTime;
    private javax.swing.JRadioButton rdFour;
    private javax.swing.JRadioButton rdOne;
    private javax.swing.JRadioButton rdThree;
    private javax.swing.JRadioButton rdTwo;
    // End of variables declaration//GEN-END:variables
}
