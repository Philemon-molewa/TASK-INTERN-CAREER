package intern_career;

/**
 * Java calculator application
 *
 * @author (PHILEMON Molewa)
 */
public class Calculator
{

    public static void main(String[] args)
    {

    }
}
